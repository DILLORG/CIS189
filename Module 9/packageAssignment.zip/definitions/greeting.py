def friendly_greeting():
    """
    Prints a friendly greeting to the console.
    :params none
    :returns none
    """
    print("Hello there!")


def print_author():
    """
    Prints the authors name.
    :params none
    :returns none
    """
    print("author: Dylan Kennedy")
